'use strict';

var ConsentUtil = require('../database/ConsentDatabase');

var ConsentValidator = require('../domain/PartyConsent.js');

exports.createPartyConsent = function(args,req, res, next) {
  /**
   * parameters expected in the args:
  * party (PartyFull)
  **/
  
  ConsentValidator.validateAndCreatePartyConsentObj(args,req, function(err,args){
    if(err != null ){
        console.log("Error in input object" + err);
        createPersistResponse(err,res);
    }else{
        var retStatus="No response";
        ConsentUtil.persistPartyConsent(args['Party'].value,function(err,result) {
          if(err != null){
            retStatus=err;
          }else{
            retStatus="Persisted successfully - "+result;
          }
          createPersistResponse(retStatus,res);
        });
    }
    });
    
}

var createPersistResponse = function(retStatus,res){
  var examples = {};
  console.log(retStatus);
  examples['application/json'] = retStatus;
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
}


exports.retrievePartyConsent = function(args, res, next) {
  /**
   * parameters expected in the args:
  * partyId (String)
  * sourceType (String)
  **/
  
  ConsentUtil.retrievePartyConsent(args,function(err,result){
    var retVal;
    if(err != null){
      retVal = err;
    }else{
      retVal = result;
    }
    createRetrieveResponse(retVal,res);
  });
}

var createRetrieveResponse = function(result,res){
  console.log(result);
  //if(Object.keys(result).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    //res.end(JSON.stringify(result || {}, null, 2));
    res.write(JSON.stringify(result));
    res.end();
  //}
  //else {
   // res.end();
  //}
}
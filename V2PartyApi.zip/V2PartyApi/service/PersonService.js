'use strict';

exports.createPerson = function(args, res, next) {
  /**
   * parameters expected in the args:
  * party (PartyFull)
  **/
    var examples = {};
  examples['application/json'] = "aeiou";
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
}

exports.findPerson = function(args, res, next) {
  /**
   * parameters expected in the args:
  * $filter (String)
  **/
    var examples = {};
  examples['application/json'] = [ {
  "partyIdentifiers" : [ {
    "endDate" : "2000-01-23T04:56:07.000+00:00",
    "identifierValue" : "aeiou",
    "identifierType" : "aeiou",
    "partyIdentifierID" : "aeiou",
    "startDate" : "2000-01-23T04:56:07.000+00:00"
  } ],
  "partyConsent" : [ {
    "partySourceIdentifer" : "aeiou",
    "process" : "aeiou",
    "partyConsentId" : "aeiou",
    "sourceType" : "aeiou",
    "endDate" : "2000-01-23T04:56:07.000+00:00",
    "channel" : "aeiou",
    "band" : "aeiou",
    "consentIndicator" : true,
    "consentCaptureDate" : "2000-01-23T04:56:07.000+00:00",
    "startDate" : "2000-01-23T04:56:07.000+00:00"
  } ],
  "partyXrefs" : [ {
    "createdDate" : "2000-01-23T04:56:07.000+00:00",
    "sourceType" : "aeiou",
    "partyID" : "aeiou",
    "segments" : [ {
      "nameType" : "aeiou",
      "value" : "aeiou"
    } ]
  } ],
  "partyPerson" : {
    "deceasedNotificationDate" : "2000-01-23T04:56:07.000+00:00",
    "consentGeneralOptOutInd" : true,
    "defaultCurrencyType" : "aeiou",
    "annualIncome" : "aeiou",
    "maritalStatusType" : "aeiou",
    "vulnerableInd" : true,
    "dateOfBirth" : "2000-01-23T04:56:07.000+00:00",
    "partyID" : "aeiou",
    "deceasedDate" : "2000-01-23T04:56:07.000+00:00",
    "employmentStatusType" : "aeiou",
    "genderType" : "aeiou",
    "deceasedInd" : true
  },
  "partyContactMechanisms" : [ {
    "addressVirtual" : {
      "virtualType" : "aeiou",
      "addressVirtualID" : "aeiou",
      "segments" : [ {
        "nameType" : "aeiou",
        "value" : "aeiou"
      } ]
    },
    "partyContactMechanismID" : "aeiou",
    "toDate" : "2000-01-23T04:56:07.000+00:00",
    "addressPhysical" : "",
    "preferredInd" : true,
    "fromDate" : "2000-01-23T04:56:07.000+00:00",
    "brandID" : "aeiou",
    "bestTimeToContactTo" : "aeiou",
    "careOfMessage" : "aeiou",
    "partyAddressID" : "aeiou",
    "partyID" : "aeiou",
    "channelID" : "aeiou",
    "bestTimeToContactFrom" : "aeiou"
  } ],
  "partyOptOuts" : [ {
    "fromDate" : "2000-01-23T04:56:07.000+00:00",
    "toDate" : "2000-01-23T04:56:07.000+00:00",
    "optOutType" : "aeiou",
    "optOutInd" : true
  } ],
  "partyStatuses" : [ {
    "statusType" : "aeiou",
    "endDate" : "2000-01-23T04:56:07.000+00:00",
    "partyID" : "aeiou",
    "partyStatusID" : "aeiou",
    "startDate" : "2000-01-23T04:56:07.000+00:00"
  } ],
  "partyAddresses" : [ {
    "fromDate" : "2000-01-23T04:56:07.000+00:00",
    "toDate" : "2000-01-23T04:56:07.000+00:00",
    "addressPhysical" : {
      "townOrCity" : "aeiou",
      "addressType" : "aeiou",
      "latitude" : "aeiou",
      "houseNumber" : "aeiou",
      "locality" : "aeiou",
      "postcode" : "aeiou",
      "county" : "aeiou",
      "longtitude" : "aeiou",
      "countryType" : "aeiou",
      "addressPhysicalID" : "aeiou",
      "houseOrBuildingName" : "aeiou",
      "flatNameOrNumber" : "aeiou",
      "street" : "aeiou"
    },
    "partyAddressID" : "aeiou",
    "primaryResidenceInd" : true,
    "partyID" : "aeiou"
  } ],
  "partyLocations" : [ {
    "endDate" : "2000-01-23T04:56:07.000+00:00",
    "partyLocationID" : "aeiou",
    "locationID" : "aeiou",
    "partyID" : "aeiou",
    "locationRoleType" : "aeiou",
    "startDate" : "2000-01-23T04:56:07.000+00:00"
  } ],
  "partyRelationshipRoles" : [ {
    "fromDate" : "2000-01-23T04:56:07.000+00:00",
    "partyRelationshipID" : "aeiou",
    "statusType" : "aeiou",
    "partyRelationshipRoleID" : "aeiou",
    "partyRoleType" : "aeiou",
    "toDate" : "2000-01-23T04:56:07.000+00:00",
    "relationID" : "aeiou",
    "partyID" : "aeiou"
  } ],
  "partyOrganisation" : {
    "partyID" : "aeiou"
  },
  "partyLanguage" : {
    "languageType" : "aeiou",
    "partyID" : "aeiou",
    "primaryInd" : true
  },
  "partyNames" : [ {
    "prefixType" : "aeiou",
    "forename" : "aeiou",
    "otherNames" : "aeiou",
    "partyNameID" : "aeiou",
    "endDate" : "2000-01-23T04:56:07.000+00:00",
    "surname" : "aeiou",
    "nickname" : "aeiou",
    "middleName" : "aeiou",
    "partyID" : "aeiou",
    "suffix" : "aeiou",
    "mothersMaidenName" : "aeiou",
    "startDate" : "2000-01-23T04:56:07.000+00:00"
  } ],
  "partyRelationships" : [ {
    "partyRelationshipID" : "aeiou",
    "relationshipType" : "aeiou",
    "productID" : "aeiou"
  } ],
  "party" : {
    "createdDate" : "2000-01-23T04:56:07.000+00:00",
    "organisationReference" : "aeiou",
    "residentialStatusType" : "aeiou",
    "partyID" : "aeiou",
    "partyType" : "aeiou",
    "partyNumber" : ""
  }
} ];
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
}

exports.retrievePersonDetails = function(args, res, next) {
  /**
   * parameters expected in the args:
  * partyId (String)
  * systemId (String)
  **/
    var examples = {};
  examples['application/json'] = {
  "partyIdentifiers" : [ {
    "endDate" : "2000-01-23T04:56:07.000+00:00",
    "identifierValue" : "aeiou",
    "identifierType" : "aeiou",
    "partyIdentifierID" : "aeiou",
    "startDate" : "2000-01-23T04:56:07.000+00:00"
  } ],
  "partyConsent" : [ {
    "partySourceIdentifer" : "aeiou",
    "process" : "aeiou",
    "partyConsentId" : "aeiou",
    "sourceType" : "aeiou",
    "endDate" : "2000-01-23T04:56:07.000+00:00",
    "channel" : "aeiou",
    "band" : "aeiou",
    "consentIndicator" : true,
    "consentCaptureDate" : "2000-01-23T04:56:07.000+00:00",
    "startDate" : "2000-01-23T04:56:07.000+00:00"
  } ],
  "partyXrefs" : [ {
    "createdDate" : "2000-01-23T04:56:07.000+00:00",
    "sourceType" : "aeiou",
    "partyID" : "aeiou",
    "segments" : [ {
      "nameType" : "aeiou",
      "value" : "aeiou"
    } ]
  } ],
  "partyPerson" : {
    "deceasedNotificationDate" : "2000-01-23T04:56:07.000+00:00",
    "consentGeneralOptOutInd" : true,
    "defaultCurrencyType" : "aeiou",
    "annualIncome" : "aeiou",
    "maritalStatusType" : "aeiou",
    "vulnerableInd" : true,
    "dateOfBirth" : "2000-01-23T04:56:07.000+00:00",
    "partyID" : "aeiou",
    "deceasedDate" : "2000-01-23T04:56:07.000+00:00",
    "employmentStatusType" : "aeiou",
    "genderType" : "aeiou",
    "deceasedInd" : true
  },
  "partyContactMechanisms" : [ {
    "addressVirtual" : {
      "virtualType" : "aeiou",
      "addressVirtualID" : "aeiou",
      "segments" : [ {
        "nameType" : "aeiou",
        "value" : "aeiou"
      } ]
    },
    "partyContactMechanismID" : "aeiou",
    "toDate" : "2000-01-23T04:56:07.000+00:00",
    "addressPhysical" : "",
    "preferredInd" : true,
    "fromDate" : "2000-01-23T04:56:07.000+00:00",
    "brandID" : "aeiou",
    "bestTimeToContactTo" : "aeiou",
    "careOfMessage" : "aeiou",
    "partyAddressID" : "aeiou",
    "partyID" : "aeiou",
    "channelID" : "aeiou",
    "bestTimeToContactFrom" : "aeiou"
  } ],
  "partyOptOuts" : [ {
    "fromDate" : "2000-01-23T04:56:07.000+00:00",
    "toDate" : "2000-01-23T04:56:07.000+00:00",
    "optOutType" : "aeiou",
    "optOutInd" : true
  } ],
  "partyStatuses" : [ {
    "statusType" : "aeiou",
    "endDate" : "2000-01-23T04:56:07.000+00:00",
    "partyID" : "aeiou",
    "partyStatusID" : "aeiou",
    "startDate" : "2000-01-23T04:56:07.000+00:00"
  } ],
  "partyAddresses" : [ {
    "fromDate" : "2000-01-23T04:56:07.000+00:00",
    "toDate" : "2000-01-23T04:56:07.000+00:00",
    "addressPhysical" : {
      "townOrCity" : "aeiou",
      "addressType" : "aeiou",
      "latitude" : "aeiou",
      "houseNumber" : "aeiou",
      "locality" : "aeiou",
      "postcode" : "aeiou",
      "county" : "aeiou",
      "longtitude" : "aeiou",
      "countryType" : "aeiou",
      "addressPhysicalID" : "aeiou",
      "houseOrBuildingName" : "aeiou",
      "flatNameOrNumber" : "aeiou",
      "street" : "aeiou"
    },
    "partyAddressID" : "aeiou",
    "primaryResidenceInd" : true,
    "partyID" : "aeiou"
  } ],
  "partyLocations" : [ {
    "endDate" : "2000-01-23T04:56:07.000+00:00",
    "partyLocationID" : "aeiou",
    "locationID" : "aeiou",
    "partyID" : "aeiou",
    "locationRoleType" : "aeiou",
    "startDate" : "2000-01-23T04:56:07.000+00:00"
  } ],
  "partyRelationshipRoles" : [ {
    "fromDate" : "2000-01-23T04:56:07.000+00:00",
    "partyRelationshipID" : "aeiou",
    "statusType" : "aeiou",
    "partyRelationshipRoleID" : "aeiou",
    "partyRoleType" : "aeiou",
    "toDate" : "2000-01-23T04:56:07.000+00:00",
    "relationID" : "aeiou",
    "partyID" : "aeiou"
  } ],
  "partyOrganisation" : {
    "partyID" : "aeiou"
  },
  "partyLanguage" : {
    "languageType" : "aeiou",
    "partyID" : "aeiou",
    "primaryInd" : true
  },
  "partyNames" : [ {
    "prefixType" : "aeiou",
    "forename" : "aeiou",
    "otherNames" : "aeiou",
    "partyNameID" : "aeiou",
    "endDate" : "2000-01-23T04:56:07.000+00:00",
    "surname" : "aeiou",
    "nickname" : "aeiou",
    "middleName" : "aeiou",
    "partyID" : "aeiou",
    "suffix" : "aeiou",
    "mothersMaidenName" : "aeiou",
    "startDate" : "2000-01-23T04:56:07.000+00:00"
  } ],
  "partyRelationships" : [ {
    "partyRelationshipID" : "aeiou",
    "relationshipType" : "aeiou",
    "productID" : "aeiou"
  } ],
  "party" : {
    "createdDate" : "2000-01-23T04:56:07.000+00:00",
    "organisationReference" : "aeiou",
    "residentialStatusType" : "aeiou",
    "partyID" : "aeiou",
    "partyType" : "aeiou",
    "partyNumber" : ""
  }
};
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
}

exports.updatePerson = function(args, res, next) {
  /**
   * parameters expected in the args:
  * party (PartyFull)
  **/
  // no response value expected for this operation
  res.end();
}


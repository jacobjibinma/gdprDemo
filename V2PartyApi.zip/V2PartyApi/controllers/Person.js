'use strict';

var url = require('url');


var Person = require('../service/PersonService');


module.exports.createPerson = function createPerson (req, res, next) {
  Person.createPerson(req.swagger.params, res, next);
};

module.exports.findPerson = function findPerson (req, res, next) {
  Person.findPerson(req.swagger.params, res, next);
};

module.exports.retrievePersonDetails = function retrievePersonDetails (req, res, next) {
  Person.retrievePersonDetails(req.swagger.params, res, next);
};

module.exports.updatePerson = function updatePerson (req, res, next) {
  Person.updatePerson(req.swagger.params, res, next);
};

'use strict';

var url = require('url');


var Consent = require('../service/ConsentService');


module.exports.createPartyConsent = function createPartyConsent (req, res, next) {
  Consent.createPartyConsent(req.swagger.params,req, res, next);
};

module.exports.retrievePartyConsent = function retrievePartyConsent (req, res, next) {
  Consent.retrievePartyConsent(req.swagger.params, res, next);
};
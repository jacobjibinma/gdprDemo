'use strict';

var myApp = angular.module('myApp', ['720kb.datepicker']);

myApp.config(['$httpProvider', function($httpProvider) {
        $httpProvider.defaults.useXDomain = true;
        delete $httpProvider.defaults.headers.common['X-Requested-With'];
    }
]);

/* Controllers */

myApp.controller('UserListCtrl',function ($scope, $http, $templateCache) {
  
  var method = 'POST';
  var inserturl = 'http://localhost:8082/v2/Party/partyconsent/createPartyConsent';
  $scope.codeStatus = "";
  console.log($scope.startdate);
  $scope.save = function() {

    var consentIndicat=false;
    if(this.ConsentIndicator == "True"){
      consentIndicat = true;
    }
    var formData = {
        "party": {
          "partyID": this.partySourceID,
          "partyType": "Not Set",
          "residentialStatusType": "Not Set",
          "organisationReference": "string",
          "createdDate": getFormattedDate(),
          "partyNumber": 0
        },
        
        "partyConsent": [
        {
            "partyConsentId": "00A",
            "consentCaptureDate": getFormattedDate(),
            "partySourceIdentifer": this.partySourceID,
            "sourceType": this.sourcType,
            "band": "string",
            "process": "Angular UI",
            "channel": this.channel,
            "consentIndicator": consentIndicat,
            "startDate":this.startdate,
            "endDate": this.enddate
          }
        ]
    };
	this.partySourceID = '';
	this.sourcType = '';
	this.channel = '';
	this.ConsentIndicator = '';
  this.startdate='';
  this.enddate='';
	var jdata = JSON.stringify(formData);
	console.log(jdata);
	$http({
      method: method,
      url: inserturl,
      data:  jdata ,
      headers: {'Content-Type': 'application/json'},
      cache: $templateCache
    }).
    success(function(response) {
		console.log("success from post");
    //$scope.codeStatus = response.data;
		console.log(response);
    
    }).
    error(function(response) {
		console.log("error");
    //$scope.codeStatus = response || "Request failed";
		console.log(response);
    });
	$scope.list();
    return false;
  };	
  
  $scope.list = function() {
	  var geturl = 'http://127.0.0.1:8082/v2/Party/partyconsent/retrievePartyConsent?partyId='+$scope.partySourceID+'&sourceType='+$scope.sourcType;
	  $http.get(geturl).then(function(response) {
    $scope.getconsents=response.data;  
    console.log('my result'); 
    console.log(JSON.stringify(response.data));      
	  });
  };
  
  //$scope.list();
});

//get of new date
function getFormattedDate() {
  var date = new Date();

  var month = date.getMonth() + 1;
  var day = date.getDate();
  var hour = date.getHours();
  var min = date.getMinutes();
  var sec = date.getSeconds();

  month = (month < 10 ? "0" : "") + month;
  day = (day < 10 ? "0" : "") + day;
  hour = (hour < 10 ? "0" : "") + hour;
  min = (min < 10 ? "0" : "") + min;
  sec = (sec < 10 ? "0" : "") + sec;

  //var str = date.getFullYear() + "-" + month + "-" + day + "_" +  hour + ":" + min + ":" + sec;
  var str = date.getFullYear() + "-" + month + "-" + day;

  /*alert(str);*/

  return str;
}

//PhoneListCtrl.$inject = ['$scope', '$http'];
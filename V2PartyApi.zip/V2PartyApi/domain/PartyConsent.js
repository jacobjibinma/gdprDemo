
'use strict';

exports.validateAndCreatePartyConsentObj = function validateAndCreatePartyConsentObj(args,req, callback){

    // implement logic for validation and input request creation
    // logic here to get the party arg and do necessary validation and convert to JSOn oblect structure

    console.log(req.body);

    callback(null,args);
}
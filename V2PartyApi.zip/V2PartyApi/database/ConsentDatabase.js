'use strict';

var MongoClient = require('mongodb').MongoClient;
var assert = require('assert');
var ObjectId = require('mongodb').ObjectID;
var url = 'mongodb://localhost:27017/consentdb';

exports.persistPartyConsent = function persistPartyConsent (args,callback){
    console.log('inside persistPartyConsent');
    MongoClient.connect(url, function(err, db) {
        if(err != null){
            console.log(err);
            callback(err,null);
        }else{
            insertDocument(args, db, function(err,result) {
                if(err != null){
                    console.log(err);
                    callback(err,null);
                }else{
                    db.close();
                    callback(null,result);
                }
            });
        }
    });
     
}

var insertDocument = function(args, db, callback) {
    db.collection('consents').insertOne( args, function(err, result) {
        if(err != null){
            console.log(err);
            callback(err,null);
        }else{
            console.log("Inserted document into the consents collection.");
            callback(null,result);
        }
   });
 };

 exports.retrievePartyConsent = function retrievePartyConsent (args,callback){
    console.log('partyId - ' + args['partyId'].value);
    console.log('sourceType - ' + args['sourceType'].value);
    MongoClient.connect(url, function(err, db) {
        if(err != null){
            callback(err,null);
        }else{
            db.collection('consents', function (err, collect) {
                if(err != null){
                    callback(err,null);
                }else{
                    collect.find({ "party.partyID": args['partyId'].value, "partyConsent.sourceType": args['sourceType'].value }).sort({"party.createdDate":-1}).limit(1).toArray(function(err, result) {
                        if(err != null){
                            callback(err,null);     
                        }else{
                            console.log("retrieved document from the consents collection."); 
                            db.close();
                            callback(null,result);
                        }
                    });
                 }
            });  
        }
      });
 }
